﻿
Public Class clsScottPlot
    Public Function BoxPlotAllData(ByRef dt As DataTable, ByVal i As Integer) As List(Of ScottPlot.Plottables.Box)
        Dim l As New List(Of ScottPlot.Plottables.Box)

        Dim box1 As New ScottPlot.Plottables.Box With {
            .BoxMin = 0,
            .BoxMax = 6,
            .BoxMiddle = 4,
            .WhiskerMin = -3,
            .WhiskerMax = 13
        }

        Dim box2 As New ScottPlot.Plottables.Box With {
            .BoxMin = 2,
            .BoxMax = 10,
            .BoxMiddle = 4,
            .WhiskerMin = 0,
            .WhiskerMax = 13
        }

        Dim box3 As New ScottPlot.Plottables.Box With {
            .BoxMin = 8,
            .BoxMax = 10,
            .BoxMiddle = 9,
            .WhiskerMin = 3,
            .WhiskerMax = 13
        }

        l.Add(box1)
        l.Add(box2)
        l.Add(box3)

        Return l

    End Function

End Class
