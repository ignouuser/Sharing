﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.MentQTabControl1 = New MentQ.MentQTabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.MentQButton1 = New MentQ.MentQButton()
        Me.MentQGroupBox3 = New MentQ.MentQGroupBox()
        Me.rbTrend = New MentQ.MentQRadioButton()
        Me.rbBoxPlot = New MentQ.MentQRadioButton()
        Me.MentQGroupBox2 = New MentQ.MentQGroupBox()
        Me.cboGrouping = New System.Windows.Forms.ComboBox()
        Me.MentQGroupBox1 = New MentQ.MentQGroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dtpTo = New System.Windows.Forms.DateTimePicker()
        Me.dtpFrom = New System.Windows.Forms.DateTimePicker()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.MentQButton2 = New MentQ.MentQButton()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.DataBase = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Table = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DateColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ParamCol = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ParamVal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SeriesType = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.BoxParameter = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.IsActive = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.MentQGroupBox4 = New MentQ.MentQGroupBox()
        Me.MentQGroupBox5 = New MentQ.MentQGroupBox()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewComboBoxColumn1 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.DataGridViewComboBoxColumn2 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.DataGridViewCheckBoxColumn1 = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.MentQTabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.MentQGroupBox3.SuspendLayout()
        Me.MentQGroupBox2.SuspendLayout()
        Me.MentQGroupBox1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MentQGroupBox4.SuspendLayout()
        Me.MentQGroupBox5.SuspendLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MentQTabControl1
        '
        Me.MentQTabControl1.Alignment = System.Windows.Forms.TabAlignment.Left
        Me.MentQTabControl1.Controls.Add(Me.TabPage1)
        Me.MentQTabControl1.Controls.Add(Me.TabPage2)
        Me.MentQTabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MentQTabControl1.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed
        Me.MentQTabControl1.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.MentQTabControl1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.MentQTabControl1.ItemSize = New System.Drawing.Size(35, 175)
        Me.MentQTabControl1.Location = New System.Drawing.Point(0, 0)
        Me.MentQTabControl1.Multiline = True
        Me.MentQTabControl1.Name = "MentQTabControl1"
        Me.MentQTabControl1.SelectedColor = System.Drawing.Color.FromArgb(CType(CType(200, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.MentQTabControl1.SelectedIndex = 0
        Me.MentQTabControl1.Size = New System.Drawing.Size(972, 507)
        Me.MentQTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.MentQTabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.SystemColors.Control
        Me.TabPage1.Controls.Add(Me.FlowLayoutPanel1)
        Me.TabPage1.Controls.Add(Me.MentQButton1)
        Me.TabPage1.Controls.Add(Me.MentQGroupBox3)
        Me.TabPage1.Controls.Add(Me.MentQGroupBox2)
        Me.TabPage1.Controls.Add(Me.MentQGroupBox1)
        Me.TabPage1.Location = New System.Drawing.Point(179, 4)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(789, 499)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Main"
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanel1.BackColor = System.Drawing.SystemColors.Control
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(227, 29)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(545, 453)
        Me.FlowLayoutPanel1.TabIndex = 4
        '
        'MentQButton1
        '
        Me.MentQButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.MentQButton1.Font = New System.Drawing.Font("Verdana", 11.0!)
        Me.MentQButton1.ForeColor = System.Drawing.Color.White
        Me.MentQButton1.Location = New System.Drawing.Point(21, 399)
        Me.MentQButton1.Name = "MentQButton1"
        Me.MentQButton1.Size = New System.Drawing.Size(186, 23)
        Me.MentQButton1.TabIndex = 3
        Me.MentQButton1.Text = "Plot"
        Me.MentQButton1.Underline = False
        Me.MentQButton1.UnderlineColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.MentQButton1.UnderlineSize = 2
        Me.MentQButton1.UseVisualStyleBackColor = False
        '
        'MentQGroupBox3
        '
        Me.MentQGroupBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.MentQGroupBox3.BorderColor = System.Drawing.Color.FromArgb(CType(CType(180, Byte), Integer), CType(CType(180, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.MentQGroupBox3.Closable = False
        Me.MentQGroupBox3.Closed = False
        Me.MentQGroupBox3.Controls.Add(Me.rbTrend)
        Me.MentQGroupBox3.Controls.Add(Me.rbBoxPlot)
        Me.MentQGroupBox3.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.MentQGroupBox3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.MentQGroupBox3.Icon = Nothing
        Me.MentQGroupBox3.Location = New System.Drawing.Point(21, 279)
        Me.MentQGroupBox3.Name = "MentQGroupBox3"
        Me.MentQGroupBox3.Size = New System.Drawing.Size(186, 100)
        Me.MentQGroupBox3.TabIndex = 2
        Me.MentQGroupBox3.Text = "Chart Type"
        Me.MentQGroupBox3.UpperColor = System.Drawing.Color.Empty
        '
        'rbTrend
        '
        Me.rbTrend.AutoSize = True
        Me.rbTrend.BackColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.rbTrend.Font = New System.Drawing.Font("Verdana", 11.0!)
        Me.rbTrend.ForeColor = System.Drawing.Color.Black
        Me.rbTrend.Location = New System.Drawing.Point(14, 67)
        Me.rbTrend.Name = "rbTrend"
        Me.rbTrend.Size = New System.Drawing.Size(66, 14)
        Me.rbTrend.TabIndex = 1
        Me.rbTrend.Text = "Trend"
        Me.rbTrend.UseVisualStyleBackColor = False
        '
        'rbBoxPlot
        '
        Me.rbBoxPlot.AutoSize = True
        Me.rbBoxPlot.BackColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.rbBoxPlot.Checked = True
        Me.rbBoxPlot.Font = New System.Drawing.Font("Verdana", 11.0!)
        Me.rbBoxPlot.ForeColor = System.Drawing.Color.Black
        Me.rbBoxPlot.Location = New System.Drawing.Point(14, 38)
        Me.rbBoxPlot.Name = "rbBoxPlot"
        Me.rbBoxPlot.Size = New System.Drawing.Size(79, 14)
        Me.rbBoxPlot.TabIndex = 0
        Me.rbBoxPlot.TabStop = True
        Me.rbBoxPlot.Text = "BoxPlot"
        Me.rbBoxPlot.UseVisualStyleBackColor = False
        '
        'MentQGroupBox2
        '
        Me.MentQGroupBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.MentQGroupBox2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(180, Byte), Integer), CType(CType(180, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.MentQGroupBox2.Closable = False
        Me.MentQGroupBox2.Closed = False
        Me.MentQGroupBox2.Controls.Add(Me.cboGrouping)
        Me.MentQGroupBox2.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.MentQGroupBox2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.MentQGroupBox2.Icon = Nothing
        Me.MentQGroupBox2.Location = New System.Drawing.Point(21, 174)
        Me.MentQGroupBox2.Name = "MentQGroupBox2"
        Me.MentQGroupBox2.Size = New System.Drawing.Size(186, 85)
        Me.MentQGroupBox2.TabIndex = 1
        Me.MentQGroupBox2.Text = "Grouping Input"
        Me.MentQGroupBox2.UpperColor = System.Drawing.Color.Empty
        '
        'cboGrouping
        '
        Me.cboGrouping.FormattingEnabled = True
        Me.cboGrouping.Items.AddRange(New Object() {"Daily", "Weekly", "Monthly", "Yearly"})
        Me.cboGrouping.Location = New System.Drawing.Point(14, 44)
        Me.cboGrouping.Name = "cboGrouping"
        Me.cboGrouping.Size = New System.Drawing.Size(159, 28)
        Me.cboGrouping.TabIndex = 0
        '
        'MentQGroupBox1
        '
        Me.MentQGroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.MentQGroupBox1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(180, Byte), Integer), CType(CType(180, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.MentQGroupBox1.Closable = False
        Me.MentQGroupBox1.Closed = False
        Me.MentQGroupBox1.Controls.Add(Me.Label1)
        Me.MentQGroupBox1.Controls.Add(Me.dtpTo)
        Me.MentQGroupBox1.Controls.Add(Me.dtpFrom)
        Me.MentQGroupBox1.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MentQGroupBox1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.MentQGroupBox1.Icon = Nothing
        Me.MentQGroupBox1.Location = New System.Drawing.Point(21, 29)
        Me.MentQGroupBox1.Name = "MentQGroupBox1"
        Me.MentQGroupBox1.Size = New System.Drawing.Size(186, 128)
        Me.MentQGroupBox1.TabIndex = 0
        Me.MentQGroupBox1.Text = "Date Range Input"
        Me.MentQGroupBox1.UpperColor = System.Drawing.Color.Empty
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(80, 68)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(15, 20)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "-"
        '
        'dtpTo
        '
        Me.dtpTo.CustomFormat = "dd-MMM-yyyy"
        Me.dtpTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpTo.Location = New System.Drawing.Point(14, 88)
        Me.dtpTo.Name = "dtpTo"
        Me.dtpTo.Size = New System.Drawing.Size(159, 27)
        Me.dtpTo.TabIndex = 1
        '
        'dtpFrom
        '
        Me.dtpFrom.CustomFormat = "dd-MMM-yyyy"
        Me.dtpFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpFrom.Location = New System.Drawing.Point(14, 39)
        Me.dtpFrom.Name = "dtpFrom"
        Me.dtpFrom.Size = New System.Drawing.Size(159, 27)
        Me.dtpFrom.TabIndex = 0
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.SystemColors.Control
        Me.TabPage2.Controls.Add(Me.MentQGroupBox5)
        Me.TabPage2.Controls.Add(Me.MentQGroupBox4)
        Me.TabPage2.Controls.Add(Me.MentQButton2)
        Me.TabPage2.Location = New System.Drawing.Point(179, 4)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(789, 499)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Settings"
        '
        'MentQButton2
        '
        Me.MentQButton2.BackColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(105, Byte), Integer), CType(CType(205, Byte), Integer))
        Me.MentQButton2.Font = New System.Drawing.Font("Verdana", 11.0!)
        Me.MentQButton2.ForeColor = System.Drawing.Color.White
        Me.MentQButton2.Location = New System.Drawing.Point(12, 16)
        Me.MentQButton2.Name = "MentQButton2"
        Me.MentQButton2.Size = New System.Drawing.Size(75, 23)
        Me.MentQButton2.TabIndex = 1
        Me.MentQButton2.Text = "Save"
        Me.MentQButton2.Underline = False
        Me.MentQButton2.UnderlineColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.MentQButton2.UnderlineSize = 2
        Me.MentQButton2.UseVisualStyleBackColor = False
        '
        'DataGridView1
        '
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle6.Padding = New System.Windows.Forms.Padding(4)
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.Black
        Me.DataGridView1.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle6
        Me.DataGridView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.ActiveCaption
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.Padding = New System.Windows.Forms.Padding(4)
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataBase, Me.Table, Me.Column, Me.DateColumn, Me.ParamCol, Me.ParamVal, Me.SeriesType, Me.BoxParameter, Me.IsActive})
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        DataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer))
        DataGridViewCellStyle8.Padding = New System.Windows.Forms.Padding(4)
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle8
        Me.DataGridView1.Location = New System.Drawing.Point(3, 30)
        Me.DataGridView1.Name = "DataGridView1"
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle9.Padding = New System.Windows.Forms.Padding(4)
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Info
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.ControlDarkDark
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.RowHeadersDefaultCellStyle = DataGridViewCellStyle9
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle10.Padding = New System.Windows.Forms.Padding(4)
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.Black
        Me.DataGridView1.RowsDefaultCellStyle = DataGridViewCellStyle10
        Me.DataGridView1.RowTemplate.DefaultCellStyle.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DataGridView1.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black
        Me.DataGridView1.RowTemplate.DefaultCellStyle.Padding = New System.Windows.Forms.Padding(4)
        Me.DataGridView1.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.DataGridView1.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black
        Me.DataGridView1.RowTemplate.Height = 28
        Me.DataGridView1.Size = New System.Drawing.Size(763, 83)
        Me.DataGridView1.TabIndex = 0
        '
        'DataBase
        '
        Me.DataBase.DataPropertyName = "Database"
        Me.DataBase.HeaderText = "DataBase"
        Me.DataBase.Name = "DataBase"
        Me.DataBase.Width = 150
        '
        'Table
        '
        Me.Table.DataPropertyName = "Table"
        Me.Table.HeaderText = "Table"
        Me.Table.Name = "Table"
        Me.Table.Width = 150
        '
        'Column
        '
        Me.Column.DataPropertyName = "Column"
        Me.Column.HeaderText = "Column"
        Me.Column.Name = "Column"
        Me.Column.Width = 150
        '
        'DateColumn
        '
        Me.DateColumn.DataPropertyName = "DateColumn"
        Me.DateColumn.HeaderText = "DateColumn"
        Me.DateColumn.Name = "DateColumn"
        '
        'ParamCol
        '
        Me.ParamCol.DataPropertyName = "ParamCol"
        Me.ParamCol.HeaderText = "ParamCol"
        Me.ParamCol.Name = "ParamCol"
        '
        'ParamVal
        '
        Me.ParamVal.DataPropertyName = "ParamVal"
        Me.ParamVal.HeaderText = "ParamVal"
        Me.ParamVal.Name = "ParamVal"
        '
        'SeriesType
        '
        Me.SeriesType.DataPropertyName = "SeriesType"
        Me.SeriesType.HeaderText = "SeriesType"
        Me.SeriesType.Items.AddRange(New Object() {"BoxPlot"})
        Me.SeriesType.Name = "SeriesType"
        Me.SeriesType.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.SeriesType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        '
        'BoxParameter
        '
        Me.BoxParameter.DataPropertyName = "BoxParameter"
        Me.BoxParameter.HeaderText = "BoxParameter"
        Me.BoxParameter.Items.AddRange(New Object() {"Min", "Max", "Avg", "StDev"})
        Me.BoxParameter.Name = "BoxParameter"
        '
        'IsActive
        '
        Me.IsActive.DataPropertyName = "IsActive"
        Me.IsActive.HeaderText = "IsActive"
        Me.IsActive.Name = "IsActive"
        Me.IsActive.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        '
        'MentQGroupBox4
        '
        Me.MentQGroupBox4.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MentQGroupBox4.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.MentQGroupBox4.BorderColor = System.Drawing.Color.FromArgb(CType(CType(180, Byte), Integer), CType(CType(180, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.MentQGroupBox4.Closable = False
        Me.MentQGroupBox4.Closed = False
        Me.MentQGroupBox4.Controls.Add(Me.DataGridView1)
        Me.MentQGroupBox4.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.MentQGroupBox4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.MentQGroupBox4.Icon = Nothing
        Me.MentQGroupBox4.Location = New System.Drawing.Point(12, 56)
        Me.MentQGroupBox4.Name = "MentQGroupBox4"
        Me.MentQGroupBox4.Size = New System.Drawing.Size(769, 116)
        Me.MentQGroupBox4.TabIndex = 2
        Me.MentQGroupBox4.Text = "BoxPlot"
        Me.MentQGroupBox4.UpperColor = System.Drawing.Color.Empty
        '
        'MentQGroupBox5
        '
        Me.MentQGroupBox5.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MentQGroupBox5.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.MentQGroupBox5.BorderColor = System.Drawing.Color.FromArgb(CType(CType(180, Byte), Integer), CType(CType(180, Byte), Integer), CType(CType(180, Byte), Integer))
        Me.MentQGroupBox5.Closable = False
        Me.MentQGroupBox5.Closed = False
        Me.MentQGroupBox5.Controls.Add(Me.DataGridView2)
        Me.MentQGroupBox5.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.MentQGroupBox5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.MentQGroupBox5.Icon = Nothing
        Me.MentQGroupBox5.Location = New System.Drawing.Point(12, 178)
        Me.MentQGroupBox5.Name = "MentQGroupBox5"
        Me.MentQGroupBox5.Size = New System.Drawing.Size(769, 302)
        Me.MentQGroupBox5.TabIndex = 3
        Me.MentQGroupBox5.Text = "Trend"
        Me.MentQGroupBox5.UpperColor = System.Drawing.Color.Empty
        '
        'DataGridView2
        '
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle1.Padding = New System.Windows.Forms.Padding(4)
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black
        Me.DataGridView2.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders
        Me.DataGridView2.BackgroundColor = System.Drawing.SystemColors.ActiveCaption
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.Padding = New System.Windows.Forms.Padding(4)
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView2.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.DataGridViewComboBoxColumn1, Me.DataGridViewComboBoxColumn2, Me.DataGridViewCheckBoxColumn1})
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer))
        DataGridViewCellStyle3.Padding = New System.Windows.Forms.Padding(4)
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView2.DefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridView2.Location = New System.Drawing.Point(3, 29)
        Me.DataGridView2.Name = "DataGridView2"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.Padding = New System.Windows.Forms.Padding(4)
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Info
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.ControlDarkDark
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView2.RowHeadersDefaultCellStyle = DataGridViewCellStyle4
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle5.Padding = New System.Windows.Forms.Padding(4)
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.Black
        Me.DataGridView2.RowsDefaultCellStyle = DataGridViewCellStyle5
        Me.DataGridView2.RowTemplate.DefaultCellStyle.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DataGridView2.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black
        Me.DataGridView2.RowTemplate.DefaultCellStyle.Padding = New System.Windows.Forms.Padding(4)
        Me.DataGridView2.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.DataGridView2.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black
        Me.DataGridView2.RowTemplate.Height = 28
        Me.DataGridView2.Size = New System.Drawing.Size(763, 270)
        Me.DataGridView2.TabIndex = 0
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "Database"
        Me.DataGridViewTextBoxColumn1.HeaderText = "DataBase"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Width = 150
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Table"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Table"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Width = 150
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "Column"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Column"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 150
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "DateColumn"
        Me.DataGridViewTextBoxColumn4.HeaderText = "DateColumn"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "ParamCol"
        Me.DataGridViewTextBoxColumn5.HeaderText = "ParamCol"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "ParamVal"
        Me.DataGridViewTextBoxColumn6.HeaderText = "ParamVal"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        '
        'DataGridViewComboBoxColumn1
        '
        Me.DataGridViewComboBoxColumn1.DataPropertyName = "SeriesType"
        Me.DataGridViewComboBoxColumn1.HeaderText = "SeriesType"
        Me.DataGridViewComboBoxColumn1.Items.AddRange(New Object() {"BoxPlot"})
        Me.DataGridViewComboBoxColumn1.Name = "DataGridViewComboBoxColumn1"
        Me.DataGridViewComboBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewComboBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        '
        'DataGridViewComboBoxColumn2
        '
        Me.DataGridViewComboBoxColumn2.DataPropertyName = "Function"
        Me.DataGridViewComboBoxColumn2.HeaderText = "Function"
        Me.DataGridViewComboBoxColumn2.Items.AddRange(New Object() {"Moving Average"})
        Me.DataGridViewComboBoxColumn2.Name = "DataGridViewComboBoxColumn2"
        '
        'DataGridViewCheckBoxColumn1
        '
        Me.DataGridViewCheckBoxColumn1.DataPropertyName = "IsActive"
        Me.DataGridViewCheckBoxColumn1.HeaderText = "IsActive"
        Me.DataGridViewCheckBoxColumn1.Name = "DataGridViewCheckBoxColumn1"
        Me.DataGridViewCheckBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(972, 507)
        Me.Controls.Add(Me.MentQTabControl1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MentQTabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.MentQGroupBox3.ResumeLayout(False)
        Me.MentQGroupBox3.PerformLayout()
        Me.MentQGroupBox2.ResumeLayout(False)
        Me.MentQGroupBox1.ResumeLayout(False)
        Me.MentQGroupBox1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MentQGroupBox4.ResumeLayout(False)
        Me.MentQGroupBox5.ResumeLayout(False)
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents MentQTabControl1 As MentQ.MentQTabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents MentQButton1 As MentQ.MentQButton
    Friend WithEvents MentQGroupBox3 As MentQ.MentQGroupBox
    Friend WithEvents rbTrend As MentQ.MentQRadioButton
    Friend WithEvents rbBoxPlot As MentQ.MentQRadioButton
    Friend WithEvents MentQGroupBox2 As MentQ.MentQGroupBox
    Friend WithEvents cboGrouping As ComboBox
    Friend WithEvents MentQGroupBox1 As MentQ.MentQGroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents dtpTo As DateTimePicker
    Friend WithEvents dtpFrom As DateTimePicker
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents MentQButton2 As MentQ.MentQButton
    Friend WithEvents DataBase As DataGridViewTextBoxColumn
    Friend WithEvents Table As DataGridViewTextBoxColumn
    Friend WithEvents Column As DataGridViewTextBoxColumn
    Friend WithEvents DateColumn As DataGridViewTextBoxColumn
    Friend WithEvents ParamCol As DataGridViewTextBoxColumn
    Friend WithEvents ParamVal As DataGridViewTextBoxColumn
    Friend WithEvents SeriesType As DataGridViewComboBoxColumn
    Friend WithEvents BoxParameter As DataGridViewComboBoxColumn
    Friend WithEvents IsActive As DataGridViewCheckBoxColumn
    Friend WithEvents MentQGroupBox5 As MentQ.MentQGroupBox
    Friend WithEvents DataGridView2 As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewComboBoxColumn1 As DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewComboBoxColumn2 As DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewCheckBoxColumn1 As DataGridViewCheckBoxColumn
    Friend WithEvents MentQGroupBox4 As MentQ.MentQGroupBox
End Class
