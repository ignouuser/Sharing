﻿Imports System.IO

Public Class Form1

    Dim ds, ds1 As DataSet

    Private Sub MentQButton1_Click(sender As Object, e As EventArgs) Handles MentQButton1.Click
        Dim obj As New clsScottPlot

        For i As Integer = 0 To ds.Tables(0).Rows.Count - 1
            If cboGrouping.Text = "" Then
                'plot all data
                Dim l As List(Of ScottPlot.Plottables.Box) = obj.BoxPlotAllData(Nothing, Nothing)

                Dim myplot As New ScottPlot.WinForms.FormsPlot
                myplot.Plot.Add.Box(l)
                myplot.Width = 260
                myplot.Height = 260

                myplot.BackColor = Color.White

                myplot.Refresh()


                FlowLayoutPanel1.Controls.Add(myplot)

                'FlowLayoutPanel1.Controls.Add(objchart)
            End If
        Next







    End Sub

    Private Sub MentQButton2_Click(sender As Object, e As EventArgs) Handles MentQButton2.Click
        Dim dt As New DataTable

        dt.Columns.Add("Database")
        dt.Columns.Add("Table")
        dt.Columns.Add("Column")
        dt.Columns.Add("DateColumn")
        dt.Columns.Add("ParamCol")
        dt.Columns.Add("ParamVal")
        dt.Columns.Add("SeriesType")
        dt.Columns.Add("BoxParameter")
        dt.Columns.Add("IsActive", GetType(Boolean))

        For i As Integer = 0 To DataGridView1.Rows.Count - 1
            If String.IsNullOrEmpty(DataGridView1.Rows(i).Cells(0).Value) Then
                Exit For
            End If
            dt.Rows.Add(DataGridView1.Rows(i).Cells(0).Value, DataGridView1.Rows(i).Cells(1).Value, DataGridView1.Rows(i).Cells(2).Value, DataGridView1.Rows(i).Cells(3).Value, DataGridView1.Rows(i).Cells(4).Value, DataGridView1.Rows(i).Cells(5).Value, DataGridView1.Rows(i).Cells(6).Value, DataGridView1.Rows(i).Cells(7).Value, DataGridView1.Rows(i).Cells(8).Value)
        Next

        ds = New DataSet
        ds.Tables.Add(dt)

        ds.WriteXml(Application.StartupPath & "\settings.xml")

        Dim dt1 As New DataTable

        dt1.Columns.Add("Database")
        dt1.Columns.Add("Table")
        dt1.Columns.Add("Column")
        dt1.Columns.Add("DateColumn")
        dt1.Columns.Add("ParamCol")
        dt1.Columns.Add("ParamVal")
        dt1.Columns.Add("SeriesType")
        dt1.Columns.Add("Function")
        dt1.Columns.Add("IsActive", GetType(Boolean))

        For i As Integer = 0 To DataGridView1.Rows.Count - 1
            If String.IsNullOrEmpty(DataGridView1.Rows(i).Cells(0).Value) Then
                Exit For
            End If
            dt1.Rows.Add(DataGridView2.Rows(i).Cells(0).Value, DataGridView1.Rows(i).Cells(1).Value, DataGridView1.Rows(i).Cells(2).Value, DataGridView1.Rows(i).Cells(3).Value, DataGridView1.Rows(i).Cells(4).Value, DataGridView1.Rows(i).Cells(5).Value, DataGridView1.Rows(i).Cells(6).Value, DataGridView1.Rows(i).Cells(7).Value, DataGridView1.Rows(i).Cells(8).Value)
        Next

        ds1 = New DataSet
        ds1.Tables.Add(dt1)

        ds1.WriteXml(Application.StartupPath & "\settings_trend.xml")

        MsgBox("Saved successfully")
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles Me.Load

        If File.Exists(Application.StartupPath & "\settings.xml") Then
            ds = New DataSet

            ds.ReadXml(Application.StartupPath & "\settings.xml")

            DataGridView1.DataSource = ds.Tables(0)
        End If

        If File.Exists(Application.StartupPath & "\settings_trend.xml") Then
            ds1 = New DataSet

            ds1.ReadXml(Application.StartupPath & "\settings_trend.xml")

            DataGridView2.DataSource = ds1.Tables(0)

        End If


        dtpFrom.Value = DateTime.Now.AddDays(-10)
        dtpTo.Value = DateTime.Now
    End Sub
End Class
