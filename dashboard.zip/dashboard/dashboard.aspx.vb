﻿Imports System.Data
Imports System.Drawing
Imports System.IO

Partial Class dashboard
    Inherits System.Web.UI.Page
    Dim objhandler As New datahandlercpl
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Dim dt As DataTable = objhandler.GetDataSetFromQuery("select * from Teams order by teamid").Tables(0)

            Dim dtstat As New DataTable

            Dim dtteam As New DataTable
            dtteam.Columns.Add("teamid")

            Dim dtfinal As New DataTable
            dtfinal.Columns.Add("Teams")
            dtstat.Columns.Add("Department")
            dtstat.Columns.Add("Min")
            dtstat.Columns.Add("Max")
            For c As Integer = 0 To dt.Rows.Count - 1
                dtfinal.Columns.Add(dt.Rows(c)("teamname")) : dtstat.Columns.Add(dt.Rows(c)("teamname"))
                dtteam.Rows.Add(dt.Rows(c)("teamid"))
            Next

            Dim dttype As DataTable = objhandler.GetDataSetFromQuery("select distinct department from players order by 1").Tables(0)
            For i As Integer = 0 To dttype.Rows.Count - 1
                dtstat.Rows.Add(dttype.Rows(i)(0))
            Next



            Dim arr(dtfinal.Columns.Count - 1) As String
            arr(0) = "Balance Amt"
            dtfinal.Rows.Add(arr)
            arr(0) = "Captain"
            dtfinal.Rows.Add(arr)
            arr(0) = "Vice-Captain"
            dtfinal.Rows.Add(arr)
            For i As Integer = 1 To 30
                'Dim dr As DataRow = dtfinal.Rows.
                arr(0) = "Player " & i
                dtfinal.Rows.Add(arr)
            Next

            For i As Integer = 0 To dt.Rows.Count - 1

                Dim dtbal As DataTable = objhandler.GetDataSetFromQuery("select isnull(sum(amount),0) from FinalList where teamid=" & dt.Rows(i)("teamid")).Tables(0)
                dtfinal.Rows(0)(i + 1) = Math.Round(Funds.getFunds(dt.Rows(i)("teamname").ToString.Trim) - dtbal.Rows(0)(0), 3)
                dtfinal.Rows(1)(i + 1) = dt.Rows(i)("teamcaptain")
                dtfinal.Rows(2)(i + 1) = dt.Rows(i)("player1")
                'dtfinal.Rows(3)(i + 1) = dt.Rows(i)("player2")
                'dtfinal.Rows(4)(i + 1) = dt.Rows(i)("player3")


            Next

            For j As Integer = 0 To dtstat.Rows.Count - 1
                If j = 0 Then
                    dtstat.Rows(j)(1) = 2
                    dtstat.Rows(j)(2) = 3
                ElseIf j = 1 Then
                    dtstat.Rows(j)(1) = 11
                    dtstat.Rows(j)(2) = 13
                ElseIf j = 2 Then
                    dtstat.Rows(j)(1) = 4
                    dtstat.Rows(j)(2) = 5
                ElseIf j = 3 Then
                    dtstat.Rows(j)(1) = 4
                    dtstat.Rows(j)(2) = 5
                End If
                For i As Integer = 0 To dt.Rows.Count - 1
                    Dim dtCnt As DataTable = objhandler.GetDataSetFromQuery("select count(*) from v_final_users where teamid=" & dt.Rows(i)("teamid") & " and department = '" & dtstat.Rows(j)(0) & "'").Tables(0)
                    dtstat.Rows(j)(3 + i) = dtCnt.Rows(0)(0).ToString
                Next

            Next


            For i As Integer = 0 To dtteam.Rows.Count - 1
                Dim strow As Integer = 1

                Dim dttemp As DataTable = objhandler.GetDataSetFromQuery("select * from v_dashboard where teamid = " & dtteam.Rows(i)(0) & " order by playername").Tables(0)
                For j As Integer = 0 To dttemp.Rows.Count - 1
                    While dtfinal.Rows(strow)(i + 1).ToString <> ""
                        strow += 1

                    End While
                    dtfinal.Rows(strow)(i + 1) = dttemp.Rows(j)("playername") & " [" & dttemp.Rows(j)("amount") & "]"
                    strow += 1
                Next
            Next

            gvPlayers.DataSource = dtfinal
            gvPlayers.DataBind()

            gvStat.DataSource = dtstat
            gvStat.DataBind()
        End If
    End Sub

    Private Sub btnDownload_Click(sender As Object, e As EventArgs) Handles btnDownload.Click
        Response.Clear()
        Response.Buffer = True
        Response.AddHeader("content-disposition", "attachment;filename=dashboard.xls")
        Response.Charset = ""
        Response.ContentType = "application/vnd.ms-excel"
        Using sw As New StringWriter()
            Dim hw As New HtmlTextWriter(sw)

            'gvPlayers.HeaderRow.BackColor = Color.White
            'For Each cell As TableCell In gvPlayers.HeaderRow.Cells
            '    cell.BackColor = gvPlayers.HeaderStyle.BackColor
            'Next
            'For Each row As GridViewRow In gvPlayers.Rows
            '    row.BackColor = Color.White
            '    For Each cell As TableCell In row.Cells
            '        If row.RowIndex Mod 2 = 0 Then
            '            cell.BackColor = gvPlayers.AlternatingRowStyle.BackColor
            '        Else
            '            cell.BackColor = gvPlayers.RowStyle.BackColor
            '        End If
            '        cell.CssClass = "textmode"
            '    Next
            'Next

            gvPlayers.RenderControl(hw)

            Response.Output.Write(sw.ToString())
            Response.Flush()
            Response.[End]()
        End Using
    End Sub

    Public Overrides Sub VerifyRenderingInServerForm(control As Control)
        ' Verifies that the control is rendered
    End Sub
End Class
