﻿Imports System.Data
Imports System.IO
Partial Class bid
    Inherits System.Web.UI.Page
    Dim objhandler As New datahandlercpl

    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub
    Private Sub bid_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Dim dt As DataTable = objhandler.GetDataSetFromQuery("select distinct skill  from v_bidding order by 1").Tables(0)

            ddlSkill.DataSource = dt
            ddlSkill.DataTextField = "Skill"
            ddlSkill.DataValueField = "Skill"
            ddlSkill.DataBind()

            ddlSkill.Items.Insert(0, New ListItem("Select", "0"))
            ddlSkill.Items.Add(New ListItem("Female", "Female"))

            Dim dt1 As DataTable = objhandler.GetDataSetFromQuery("select teamid,teamname from teams order by 2").Tables(0)
            ddlTeam.DataSource = dt1
            ddlTeam.DataTextField = "teamname"
            ddlTeam.DataValueField = "teamid"
            ddlTeam.DataBind()

            ddlTeam.Items.Insert(0, New ListItem("Select", "0"))
        End If
    End Sub

    Private Sub btnShow_Click(sender As Object, e As EventArgs) Handles btnShow.Click
        Fillgrid()
        'gvPlayers.Columns(7).Visible = False
        'gvPlayers.Columns(8).Visible = False
        'gvPlayers.Columns(9).Visible = False

    End Sub

    Sub Fillgrid()
        Dim dt As DataTable
        If ddlSkill.SelectedIndex > 0 Then
            If ddlSkill.SelectedItem.Value.ToString.ToLower = "female" Then
                dt = objhandler.GetDataSetFromQuery("Select PNo,Name,   Gender, Skill,Department,BattingSkill,BowlingSkill,BasePriceRoundOff from v_bidding where lower(gender) = 'female'").Tables(0)
            Else
                dt = objhandler.GetDataSetFromQuery("Select PNo, Name,  Gender, Skill,Department,BattingSkill,BowlingSkill,BasePriceRoundOff from v_bidding where skill = '" & ddlSkill.SelectedItem.Value & "' and lower(gender)<>'female'").Tables(0)
            End If

            gvPlayers.DataSource = dt
            gvPlayers.DataBind()
        Else
            gvPlayers.DataSource = Nothing
            gvPlayers.DataBind()
        End If

    End Sub

    Private Sub gvPlayers_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles gvPlayers.RowCommand
        Dim gvrow = CType(CType(e.CommandSource, Button).NamingContainer, GridViewRow)
        Dim index = gvrow.RowIndex
    End Sub

    Private Sub gvPlayers_RowCreated(sender As Object, e As GridViewRowEventArgs) Handles gvPlayers.RowCreated
        e.Row.Cells(6).Visible = False
        e.Row.Cells(7).Visible = False
        e.Row.Cells(8).Visible = False

    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If ddlTeam.SelectedIndex > 0 Then
            Dim pno = hpno.Value

            Dim teamid = ddlTeam.SelectedItem.Value

            Dim finalprice = txtfinalprice.Text


            Dim q As String = "Insert into finallist values ('" & pno & "'," & teamid & "," & finalprice & ",getdate())"

            Try
                objhandler.RunSimpleQuery(q)
                UserMsgBoxSuccess("Saved successfully")

                Fillgrid()
            Catch ex As Exception
                UserMsgBoxError("Error occured")
            End Try

        Else
            UserMsgBoxError("Select Team")
        End If

    End Sub
End Class
