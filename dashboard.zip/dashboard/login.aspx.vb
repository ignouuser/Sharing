﻿Imports System.Data
Partial Class login
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim id As String = txtuid.Text
        Dim password As String = txtpass.Text

        Dim objhandler As New datahandlercpl

        Dim dt As DataTable = objhandler.GetDataSetFromQuery("select * from v_users where userid='" & id & "' and password='" & password & "'").Tables(0)

        If dt.Rows.Count > 0 Then
            Session("userid") = dt.Rows(0)("userid")
            Session("usertype") = dt.Rows(0)("usertype")
            Session("teamid") = dt.Rows(0)("teamid")
            Session("teamname") = dt.Rows(0)("teamname")
            Session("teamcaptain") = dt.Rows(0)("teamcaptain")
            If dt.Rows(0)("usertype").ToString.ToLower = "admin" Then
                Response.Redirect("dashboard.aspx")
            Else
                Response.Redirect("dashboarduser.aspx")
            End If
        Else
            UserMsgBoxError("Invalid credentials.")
        End If
    End Sub
End Class
