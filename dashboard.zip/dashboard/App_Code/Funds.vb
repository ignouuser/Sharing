﻿Imports Microsoft.VisualBasic

Public Class Funds

    Public Shared Function getFunds(ByVal teamname As String) As Double
        Dim retval As Double = 100.0

        'If teamname.ToLower = "aston martins" Then
        '    retval = 96.78
        'ElseIf teamname.ToLower = "bentleys" Then
        '    retval = 97.24
        'ElseIf teamname.ToLower = "bugattis" Then
        '    retval = 89.1
        'ElseIf teamname.ToLower = "cadillacs" Then
        '    retval = 95.51
        'ElseIf teamname.ToLower = "camrys" Then
        '    retval = 98.78
        'ElseIf teamname.ToLower = "ferraris" Then
        '    retval = 90.51
        'ElseIf teamname.ToLower = "humvees" Then
        '    retval = 97.23
        'ElseIf teamname.ToLower = "jaguars" Then
        '    retval = 100
        'ElseIf teamname.ToLower = "lamborghinis" Then
        '    retval = 96.16
        'ElseIf teamname.ToLower = "lexuses" Then
        '    retval = 100
        'ElseIf teamname.ToLower = "limos" Then
        '    retval = 100
        'ElseIf teamname.ToLower = "maybachs" Then
        '    retval = 90.93
        'ElseIf teamname.ToLower = "mclarens" Then
        '    retval = 96.02

        'ElseIf teamname.ToLower = "mercs" Then
        '    retval = 100
        'ElseIf teamname.ToLower = "mustangs" Then
        '    retval = 92.25
        'ElseIf teamname.ToLower = "phantoms" Then
        '    retval = 99.27
        'ElseIf teamname.ToLower = "porsches" Then
        '    retval = 100
        'ElseIf teamname.ToLower = "teslas" Then
        '    retval = 100
        'Else
        'retval = 100
        'End If

        Return retval
    End Function
End Class
