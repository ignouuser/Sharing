﻿Imports System.Data.SqlClient
Imports System.Data

Public Class datahandlercpl
    Dim connectionString As String = ConfigurationManager.ConnectionStrings("TG-cpl").ConnectionString
    Dim con As New SqlConnection(connectionString)
    Public Function GetDataSetFromQuery(ByVal SelectQuery As String) As DataSet
        Dim ds As New DataSet
        Try
            Dim da As New SqlDataAdapter(SelectQuery, con)
            da.SelectCommand.CommandTimeout = 6000
            da.Fill(ds)
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
        Return ds
    End Function

    Public Function CheckRecordsIn(ByVal TableName As String, ByVal condition As String) As Boolean
        Dim val As Boolean = False
        Try
            Dim query = "SELECT COUNT(*) FROM " & TableName & " where 1=1 " & condition
            Dim da As New SqlDataAdapter(query, con)
            Dim dt As New DataTable()
            da.Fill(dt)
            If Integer.Parse(dt.Rows(0)(0).ToString()) > 0 Then
                val = True
            End If
        Catch ex As Exception
            Throw New Exception(ex.ToString())
        End Try
        Return val
    End Function
    Public Function RunSimpleQuery(ByVal DMLQuery As String) As Integer
        Dim count As Integer = 0
        Try
            Dim cmd As New SqlCommand(DMLQuery, con)
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            count = cmd.ExecuteNonQuery()
            If con.State = ConnectionState.Open Then con.Close()
        Catch ex As Exception

            Throw New Exception(ex.ToString())
        End Try

        Return count
    End Function

    Public Function RunScalar(ByVal DMLQuery As String) As Integer
        Dim count As Integer = 0
        Try
            Dim cmd As New SqlCommand(DMLQuery, con)
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            count = cmd.ExecuteScalar
            If con.State = ConnectionState.Open Then con.Close()
        Catch ex As Exception

            Throw New Exception(ex.ToString())
        End Try

        Return count
    End Function
End Class
