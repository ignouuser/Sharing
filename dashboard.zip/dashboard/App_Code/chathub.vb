﻿Imports Microsoft.AspNet.SignalR

Public Class chathub
    Inherits Hub

    Public Sub Hello()
        Clients.All.Hello()
    End Sub

    Public Sub Send(ByVal name As String, ByVal message As String)
        Clients.All.broadcastMessage(name, message)
    End Sub

    Public Sub Notify()
        Clients.All.bn()

    End Sub
End Class
