﻿Imports System.Data
Imports OfficeOpenXml

Partial Class uploads
    Inherits System.Web.UI.Page
    Dim objhandler As New datahandlercpl

    Sub UserMsgBoxSuccess(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "successalert('" + Message + "');", True)
    End Sub

    Sub UserMsgBoxError(ByVal Message As String)
        ScriptManager.RegisterStartupScript(Me.Page, Me.GetType(), "Popup", "erroralert('" + Message + "');", True)
    End Sub

    Protected Sub btnDownloadPlayersFormat_Click(sender As Object, e As EventArgs) Handles btnDownloadPlayersFormat.Click
        Response.Clear()
        Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        Response.AddHeader("content-disposition", "attachment;  filename=players.xlsx")
        Response.TransmitFile(Server.MapPath("uploads" & "\players.xlsx"))
        Response.End()
    End Sub

    Protected Sub btnDownloadTeamsFormat_Click(sender As Object, e As EventArgs) Handles btnDownloadTeamsFormat.Click
        Response.Clear()
        Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        Response.AddHeader("content-disposition", "attachment;  filename=team.xlsx")
        Response.TransmitFile(Server.MapPath("uploads" & "\team.xlsx"))
        Response.End()
    End Sub

    Protected Sub btnUploadPlayersFormat_Click(sender As Object, e As EventArgs) Handles btnUploadPlayersFormat.Click
        If fupplayer.HasFile Then
            Dim upfilename As String = Server.MapPath("uploads") & "\player" & DateTime.Now.ToString("HHmmss") & ".xlsx"
            fupplayer.SaveAs(upfilename)
            Dim package As New ExcelPackage(New IO.FileInfo(upfilename))
            Dim workbook As ExcelWorkbook = package.Workbook
            Dim sheet As ExcelWorksheet = workbook.Worksheets(1)

            Dim strow As Integer = 2
            Dim delQry As String = ""

            If cbPlayers.Checked = True Then
                delQry = "DELETE FROM PLAYERS;"
                objhandler.RunSimpleQuery(delQry)
            End If


            strow = 2
            'player
            While Not sheet.Cells(strow, 1).Value Is Nothing

                Dim Name = sheet.Cells(strow, 1).Value
                Dim FullName = sheet.Cells(strow, 2).Value
                Dim PNo = sheet.Cells(strow, 3).Value
                Dim gender = sheet.Cells(strow, 4).Value
                Dim LocationOfPosting = sheet.Cells(strow, 5).Value
                Dim Department = sheet.Cells(strow, 6).Value
                Dim InterestedToParticipate = sheet.Cells(strow, 7).Value
                Dim TShirtSize = sheet.Cells(strow, 8).Value
                Dim skill = sheet.Cells(strow, 9).Value
                Dim BattingSkill = sheet.Cells(strow, 10).Value
                Dim BowlingSkill = sheet.Cells(strow, 11).Value
                Dim ParticipatedInTechnoCric22 = sheet.Cells(strow, 12).Value
                Dim TechnoCric22TeamName = sheet.Cells(strow, 13).Value
                Dim TeamName = sheet.Cells(strow, 14).Value
                Dim Matches = sheet.Cells(strow, 15).Value
                Dim CricheroesScore = sheet.Cells(strow, 16).Value
                Dim SelfScore = sheet.Cells(strow, 17).Value
                Dim ConsolidatedScore = sheet.Cells(strow, 18).Value
                Dim BasePrice = sheet.Cells(strow, 19).Value
                Dim BasePriceRoundOff = sheet.Cells(strow, 20).Value

                Try
                    Dim insqry As String = "INSERT INTO PLAYERS VALUES('" & Name & "','" & FullName & "','" & PNo & "','" & gender & "','" & LocationOfPosting & "','" & Department & "','" & InterestedToParticipate & "','" & TShirtSize & "','" & skill & "'," & BattingSkill & "," & BowlingSkill & ",'" & ParticipatedInTechnoCric22 & "','" & TechnoCric22TeamName & "','" & TeamName & "'," & Matches & "," & CricheroesScore & "," & SelfScore & "," & ConsolidatedScore & "," & BasePrice & "," & BasePriceRoundOff & ")"

                    objhandler.RunSimpleQuery(insqry)
                Catch ex As Exception

                End Try


                strow += 1
            End While
            UserMsgBoxSuccess("Upload Success")
        End If
    End Sub

    Protected Sub btnUploadTeamsFormat_Click(sender As Object, e As EventArgs) Handles btnUploadTeamsFormat.Click
        If fupteams.HasFile Then
            Dim upfilename As String = Server.MapPath("uploads") & "\team" & DateTime.Now.ToString("HHmmss") & ".xlsx"
            fupteams.SaveAs(upfilename)
            Dim package As New ExcelPackage(New IO.FileInfo(upfilename))
            Dim workbook As ExcelWorkbook = package.Workbook
            Dim sheet As ExcelWorksheet = workbook.Worksheets(1)

            Dim strow As Integer = 2

            If cbTeams.Checked = True Then
                Dim delQry As String = "DELETE FROM TEAMS;"
                objhandler.RunSimpleQuery(delQry)
            End If

            While Not sheet.Cells(strow, 1).Value Is Nothing
                Dim teamname As String = sheet.Cells(strow, 1).Value
                Dim teamcaptain As String = sheet.Cells(strow, 2).Value
                Dim player1 As String = sheet.Cells(strow, 3).Value
                Dim player2 As String = sheet.Cells(strow, 4).Value
                Dim player3 As String = sheet.Cells(strow, 5).Value
                'Dim uid As String = sheet.Cells(strow, 6).Value
                'Dim pass As String = sheet.Cells(strow, 7).Value

                Dim insqry As String = "INSERT INTO TEAMS VALUES('" & teamname & "','" & teamcaptain & "','" & player1 & "','" & player2 & "','" & player3 & "');"
                Dim teamid As Integer = objhandler.RunScalar(insqry)

                strow += 1
            End While
            UserMsgBoxSuccess("Upload Success")
        End If
    End Sub

    Protected Sub btnViewPlayers_Click(sender As Object, e As EventArgs) Handles btnViewPlayers.Click
        Dim dt As DataTable = objhandler.GetDataSetFromQuery("SELECT * FROM V_PLAYERS").Tables(0)
        gvplayers.DataSource = dt
        gvplayers.DataBind()
    End Sub

    Protected Sub btnViewTeams_Click(sender As Object, e As EventArgs) Handles btnViewTeams.Click
        Dim dt As DataTable = objhandler.GetDataSetFromQuery("SELECT * FROM V_VIEWS").Tables(0)
        gvteams.DataSource = dt
        gvteams.DataBind()
    End Sub

End Class
